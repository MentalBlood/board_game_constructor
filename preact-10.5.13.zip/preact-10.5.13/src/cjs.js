import * as preact from './index.js';
if (typeof module < 'u') module.exports = preact;
else self.preact = preact;
