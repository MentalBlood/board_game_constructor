module.exports = {
	repo: 'preactjs/preact',
	path: ['./{compat,debug,hooks,}/dist/**/!(*.map)'],
	branch: 'master'
};
