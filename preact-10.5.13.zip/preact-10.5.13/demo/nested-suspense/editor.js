import { createElement } from 'react';

export default function Editor({ children }) {
	return <div className="Editor">{children}</div>;
}
