import { createElement } from 'react';

export default function DropZone({ appearance }) {
	return <div>DropZone (component #{appearance})</div>;
}
