import { createElement } from 'react';

export default function SubComponent({ onClick }) {
	return <div>Lazy loaded sub component</div>;
}
