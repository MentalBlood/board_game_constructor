import { createElement } from 'react';

export default function AddNewComponent({ appearance }) {
	return <div>AddNewComponent (component #{appearance})</div>;
}
