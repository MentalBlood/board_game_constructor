module.exports = require('preact/jsx-runtime');
