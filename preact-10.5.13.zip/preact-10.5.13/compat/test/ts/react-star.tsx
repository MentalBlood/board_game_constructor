// import React from '../../src';
import * as React from '../../src';
class ReactIsh extends React.Component {
	render() {
		return <div>Text</div>
	}
}
