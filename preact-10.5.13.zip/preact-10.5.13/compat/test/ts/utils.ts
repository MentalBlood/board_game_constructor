/**
 * Assert the parameter is of a specific type.
 */
export const expectType = <T>(_: T): void => undefined;
