export {
	renderToString,
	renderToString as renderToStaticMarkup
} from 'preact-render-to-string';
