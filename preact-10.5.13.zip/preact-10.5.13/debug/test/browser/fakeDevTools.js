window.__PREACT_DEVTOOLS__ = { attachPreact: sinon.spy() };
