---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: feature request
assignees: ''

---

**Describe the feature you'd love to see**
A clear and concise description of what you'd love to see added to Preact.

**Additional context (optional)**
Add any other context or screenshots about the feature request here.
